# Project Risk Analysis Tool — Backend API

> AI-powered heuristic risk engine for engineering project evaluation.

---

## Quick Start

```bash
cd risk-analysis-backend
npm install
npm start          # Production server on http://localhost:5000
npm run dev        # Dev server with auto-reload (requires nodemon)
npm test           # Run Jest test suite with coverage report
```

---

## Folder Structure

```
risk-analysis-backend/
├── server.js                  # Express app entry point
├── package.json
├── routes/
│   └── analyze.js             # POST /api/analyze endpoint
├── services/
│   └── riskEngine.js          # Core heuristic AI risk engine
├── utils/
│   ├── validator.js           # Input schema validation
│   └── scoring.js             # Pressure dimension scoring functions
└── tests/
    └── riskEngine.test.js     # Jest unit + integration tests
```

---

## API Reference

### `POST /api/analyze`

**Request Body:**
```json
{
  "projectName":        "MobilePayApp",
  "domain":             "mobile",
  "durationWeeks":      8,
  "budgetUSD":          25000,
  "teamSize":           3,
  "teamExperience":     "junior",
  "techStack":          "flutter",
  "deadlineStrictness": "strict"
}
```

**Valid Values:**
| Field              | Options                                                                                         |
|--------------------|-------------------------------------------------------------------------------------------------|
| domain             | software, hardware, data-science, cybersecurity, iot, cloud, mobile, web, ai-ml, embedded     |
| teamExperience     | junior, mid, senior, mixed                                                                     |
| techStack          | react, angular, vue, nodejs, python, java, dotnet, flutter, kotlin, swift, rust, go, blockchain, custom |
| deadlineStrictness | flexible, moderate, strict, critical                                                           |

---

## Sample Outputs

### High Risk Scenario
```json
{
  "success": true,
  "data": {
    "projectName": "CriticalLaunch",
    "overallScore": 0.847,
    "overallSeverity": "High",
    "overallConfidence": 91,
    "riskCount": 6,
    "dimensions": {
      "timelinePressure": 0.88,
      "budgetConstraint": 0.92,
      "experienceRisk": 0.9,
      "technicalComplexity": 1.0
    },
    "summary": "Project CriticalLaunch has been assessed as HIGH risk (composite score: 84.7%)...",
    "risks": [
      {
        "id": "SCH-001",
        "category": "Schedule",
        "title": "Tight Timeline Pressure",
        "severity": "High",
        "probability": 0.888,
        "impact": 0.828,
        "score": 0.858,
        "confidence": 91,
        "explanation": "Project duration of 4 week(s) combined with a 'critical' deadline...",
        "mitigation": ["Break deliverables into 2-week sprints...", "..."]
      }
    ]
  }
}
```

### Low Risk Scenario
```json
{
  "success": true,
  "data": {
    "projectName": "SimpleWebsite",
    "overallScore": 0.198,
    "overallSeverity": "Low",
    "overallConfidence": 63,
    "riskCount": 1,
    "summary": "Project SimpleWebsite has been assessed as LOW risk (composite score: 19.8%)..."
  }
}
```

---

## Weighted Risk Formula

```
composite_score =
  (timeline_pressure  × 0.40) +
  (budget_constraint  × 0.30) +
  (experience_risk    × 0.20) +
  (technical_complexity × 0.10)
```

Severity thresholds:
- **High**:   score ≥ 0.65
- **Medium**: score ≥ 0.35
- **Low**:    score < 0.35

---

## Test Coverage

Tests cover:
- ✅ Input validation (7 cases)
- ✅ High-risk project detection
- ✅ Low-risk project detection
- ✅ Medium-risk project detection
- ✅ Edge cases (budget=0, teamSize=1, teamSize=100, maxDuration)
- ✅ HTTP integration (200/400 responses, response shape)
- ✅ Field-level assertions (probability range, confidence range)
