import { useState, useEffect, useRef } from "react";
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis,
  PieChart, Pie, Cell, Tooltip, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend,
} from "recharts";

// ── Risk Engine (mirrors backend logic, runs client-side) ──────────────────

const DEADLINE_W = { flexible: 0.2, moderate: 0.5, strict: 0.8, critical: 1.0 };
const EXPERIENCE_W = { senior: 0.1, mid: 0.4, mixed: 0.6, junior: 0.9 };
const TECH_COMPLEXITY = {
  react: 0.3, angular: 0.35, vue: 0.28, nodejs: 0.3, python: 0.25,
  java: 0.35, dotnet: 0.35, flutter: 0.4, kotlin: 0.45, swift: 0.45,
  rust: 0.7, go: 0.5, blockchain: 0.85, "ai-ml": 0.8, custom: 0.75,
};

function timelinePressure(dw, ds) {
  const d = Math.max(0, Math.min(1, 1 - (dw - 4) / 48));
  return d * 0.6 + (DEADLINE_W[ds] ?? 0.5) * 0.4;
}
function budgetConstraint(b, ts) {
  const pm = b / Math.max(ts, 1);
  return Math.max(0, Math.min(1, 1 - (pm - 5000) / 95000));
}
function experienceRisk(te) { return EXPERIENCE_W[te] ?? 0.5; }
function technicalComplexity(tech, domain) {
  const s = TECH_COMPLEXITY[tech] ?? 0.5;
  const dm = ["ai-ml","cybersecurity","blockchain","iot","embedded"].includes(domain) ? 1.25 : 1.0;
  return Math.min(1, s * dm);
}
function compositeScore(t, b, e, x) { return t*0.4 + b*0.3 + e*0.2 + x*0.1; }
function severity(s) { return s >= 0.65 ? "High" : s >= 0.35 ? "Medium" : "Low"; }

const DETECTORS = [
  {
    id:"SCH-001", cat:"Schedule", title:"Tight Timeline Pressure",
    detect(d) {
      if (d.t < 0.4) return null;
      const prob = Math.min(0.95, 0.4 + d.t*0.55), imp = Math.min(0.95, 0.3+d.t*0.6);
      return { prob, imp, score:(prob+imp)/2, conf:Math.round(60+d.t*35),
        why:`Duration of ${d.durationWeeks}w + "${d.deadlineStrictness}" deadline leaves minimal buffer. Timeline pressure: ${(d.t*100).toFixed(0)}%.`,
        fix:["Split into 2-week sprints with clear milestones","Add 15–20% time buffer per phase","Freeze non-critical scope early","Automate CI/CD to cut deploy overhead"] };
    }
  },
  {
    id:"SCH-002", cat:"Schedule", title:"Critical Deadline Crunch",
    detect(d) {
      if (!["critical","strict"].includes(d.deadlineStrictness)||d.durationWeeks>16) return null;
      return { prob:0.85, imp:0.9, score:0.87, conf:91,
        why:`${d.deadlineStrictness} deadline with only ${d.durationWeeks} weeks → crunch, tech debt, and burnout.`,
        fix:["Escalate scope reduction immediately","Hard feature-freeze at 80% of timeline","Daily standups to catch blockers in 24h"] };
    }
  },
  {
    id:"CST-001", cat:"Cost", title:"Budget Constraint & Overrun Risk",
    detect(d) {
      if (d.b < 0.35) return null;
      const prob = Math.min(0.93, 0.3+d.b*0.65), imp = Math.min(0.9,0.25+d.b*0.6);
      const pm = Math.round(d.budgetUSD / Math.max(d.teamSize,1));
      return { prob, imp, score:(prob+imp)/2, conf:Math.round(55+d.b*38),
        why:`$${d.budgetUSD.toLocaleString()} across ${d.teamSize} people = ~$${pm.toLocaleString()}/person. Budget pressure: ${(d.b*100).toFixed(0)}%.`,
        fix:["Weekly budget burn-rate tracking","Use open-source tooling to cut licensing costs","Phased payment milestones","10–15% contingency reserve"] };
    }
  },
  {
    id:"TCH-001", cat:"Technical", title:"Tech Complexity vs. Team Capability",
    detect(d) {
      if (d.x < 0.3 && d.e < 0.3) return null;
      const cr = d.x*0.55 + d.e*0.45;
      if (cr < 0.3) return null;
      const prob = Math.min(0.92, cr*1.1), imp = Math.min(0.9, cr*1.05);
      return { prob, imp, score:(prob+imp)/2, conf:Math.round(58+cr*35),
        why:`"${d.techStack}" complexity ${(d.x*100).toFixed(0)}% + "${d.teamExperience}" skill gap ${(d.e*100).toFixed(0)}% → architectural mistakes & rework.`,
        fix:["Assign a technical lead for architecture decisions","Week-1 technology spike / proof-of-concept","Code standards, peer review, lint pipeline","Targeted upskilling sessions"] };
    }
  },
  {
    id:"TCH-002", cat:"Technical", title:"Domain-Specific Technical Uncertainty",
    detect(d) {
      if (!["ai-ml","cybersecurity","blockchain","iot","embedded"].includes(d.domain)) return null;
      return { prob:0.72, imp:0.78, score:0.75, conf:82,
        why:`"${d.domain}" carries unknown unknowns: regulatory constraints, hardware deps, or security vulnerabilities hard to estimate upfront.`,
        fix:["Domain risk-assessment workshop in Week 1","Consult domain SMEs","Research/exploration phase before implementation","Document and validate all assumptions early"] };
    }
  },
  {
    id:"RES-001", cat:"Resource", title:"Understaffing & Key-Person Dependency",
    detect(d) {
      if (d.teamSize > 4) return null;
      const ss = Math.max(0,(5-d.teamSize)/4);
      const prob = Math.min(0.9,0.4+ss*0.5), imp = Math.min(0.88,0.45+ss*0.4);
      return { prob, imp, score:(prob+imp)/2, conf:Math.round(65+ss*25),
        why:`Team of ${d.teamSize}: no redundancy for critical skills. Any absence threatens delivery directly.`,
        fix:["Shared knowledge base & documented decisions","Cross-train on each other's domains","Identify emergency contractors","Define absence-response plan before dev starts"] };
    }
  },
  {
    id:"RES-002", cat:"Resource", title:"Team Overload & Burnout Risk",
    detect(d) {
      if (d.teamSize > 8 || d.t < 0.55) return null;
      const prob = Math.min(0.88,0.45+d.t*0.45);
      return { prob, imp:0.65, score:(prob+0.65)/2, conf:72,
        why:`High timeline pressure (${(d.t*100).toFixed(0)}%) across ${d.teamSize} people → unsustainable hours and quality decline.`,
        fix:["Enforce ≤45h/week sustainable pace","Rotate high-pressure tasks weekly","Mid-project retro to assess team health","Escalate resourcing to management proactively"] };
    }
  },
  {
    id:"COM-001", cat:"Communication", title:"Large Team Coordination Overhead",
    detect(d) {
      if (d.teamSize < 10) return null;
      const ch = (d.teamSize*(d.teamSize-1))/2;
      const os = Math.min(1, ch/200);
      const prob = Math.min(0.88,0.45+os*0.4), imp = Math.min(0.8,0.4+os*0.35);
      return { prob, imp, score:(prob+imp)/2, conf:Math.round(65+os*25),
        why:`${d.teamSize} people → ${ch} communication channels (Brook's Law). Without structure: misalignment and integration failures.`,
        fix:["Squad model (teams of 5–7)","Designate a scrum master","Async tools (Confluence/Notion) for docs","Cross-team syncs max twice weekly"] };
    }
  },
  {
    id:"COM-002", cat:"Communication", title:"Mixed Experience Communication Gap",
    detect(d) {
      if (d.teamExperience !== "mixed") return null;
      return { prob:0.6, imp:0.55, score:0.575, conf:68,
        why:`Mixed seniority creates friction: differing assumptions on process, quality, and vocabulary slow collaboration.`,
        fix:["Team glossary & onboarding guide","Buddy system (junior ↔ senior)","Standardise code review language","Team-norms workshop in Week 1"] };
    }
  },
];

function analyzeProject(input) {
  const t = timelinePressure(input.durationWeeks, input.deadlineStrictness);
  const b = budgetConstraint(input.budgetUSD, input.teamSize);
  const e = experienceRisk(input.teamExperience);
  const x = technicalComplexity(input.techStack, input.domain);
  const dims = { t, b, e, x, ...input };

  const risks = DETECTORS.map(det => {
    const r = det.detect(dims);
    if (!r) return null;
    return { id:det.id, category:det.cat, title:det.title,
      severity:severity(r.score),
      probability:parseFloat(r.prob.toFixed(3)),
      impact:parseFloat(r.imp.toFixed(3)),
      score:parseFloat(r.score.toFixed(3)),
      confidence:r.conf, explanation:r.why, mitigation:r.fix };
  }).filter(Boolean);

  const overall = parseFloat(compositeScore(t,b,e,x).toFixed(3));
  const catCount = {};
  risks.forEach(r => { catCount[r.category] = (catCount[r.category]||0)+1; });
  const highRisks = risks.filter(r=>r.severity==="High").map(r=>r.title);
  const topCats = [...new Set(risks.map(r=>r.category))].slice(0,3);
  const conf = Math.min(98, 60 + [t,b,e,x].filter(v=>v>=0.7||v<=0.2).length*9);

  return {
    projectName: input.projectName, overallScore: overall,
    overallSeverity: severity(overall), overallConfidence: Math.round(conf),
    riskCount: risks.length, dimensions:{timelinePressure:+t.toFixed(3),budgetConstraint:+b.toFixed(3),experienceRisk:+e.toFixed(3),technicalComplexity:+x.toFixed(3)},
    categoryDistribution: catCount, risks,
    summary: `Project "${input.projectName}" assessed as ${severity(overall).toUpperCase()} risk (score: ${(overall*100).toFixed(1)}%). ${risks.length} risk(s) across ${topCats.join(", ")}. ${highRisks.length ? `Critical: ${highRisks.slice(0,2).join("; ")}.` : "No critical risks detected."}`
  };
}

// ── Constants ──────────────────────────────────────────────────────────────
const SEV_COLOR = { High:"#ff4757", Medium:"#ffa502", Low:"#2ed573" };
const CAT_COLOR = { Schedule:"#5352ed", Cost:"#ff6b81", Technical:"#eccc68", Resource:"#1e90ff", Communication:"#a29bfe" };
const DOMAINS = ["software","hardware","data-science","cybersecurity","iot","cloud","mobile","web","ai-ml","embedded"];
const EXPERIENCES = ["junior","mid","senior","mixed"];
const STACKS = ["react","angular","vue","nodejs","python","java","dotnet","flutter","kotlin","swift","rust","go","blockchain","ai-ml","custom"];
const DEADLINES = ["flexible","moderate","strict","critical"];

const DEFAULT_FORM = {
  projectName:"", domain:"software", durationWeeks:12, budgetUSD:50000,
  teamSize:5, teamExperience:"mid", techStack:"react", deadlineStrictness:"moderate"
};

// ── Sub-components ─────────────────────────────────────────────────────────

function GlowNumber({ value, suffix="", decimals=1, color="#00d2ff" }) {
  const [display, setDisplay] = useState(0);
  useEffect(() => {
    let start = 0; const end = Number(value); const dur = 1200;
    const step = () => {
      start += (end - start) * 0.08;
      if (Math.abs(end - start) < 0.01) { setDisplay(end); return; }
      setDisplay(start); requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [value]);
  return (
    <span style={{ color, textShadow:`0 0 18px ${color}88`, fontVariantNumeric:"tabular-nums" }}>
      {display.toFixed(decimals)}{suffix}
    </span>
  );
}

function SeverityBadge({ level }) {
  const c = SEV_COLOR[level] || "#aaa";
  return (
    <span style={{
      background:`${c}22`, border:`1px solid ${c}66`, color:c,
      borderRadius:6, padding:"2px 10px", fontSize:12, fontWeight:700,
      letterSpacing:1, textTransform:"uppercase"
    }}>{level}</span>
  );
}

function RiskMeter({ score }) {
  const pct = Math.round(score*100);
  const col = score>=0.65?"#ff4757":score>=0.35?"#ffa502":"#2ed573";
  return (
    <div>
      <div style={{display:"flex",justifyContent:"space-between",marginBottom:6,fontSize:12,color:"#8892a4"}}>
        <span>RISK SCORE</span><span style={{color:col,fontWeight:700}}>{pct}%</span>
      </div>
      <div style={{background:"#1a2235",borderRadius:8,height:10,overflow:"hidden",position:"relative"}}>
        <div style={{
          width:`${pct}%`, height:"100%", borderRadius:8,
          background:`linear-gradient(90deg,${col}88,${col})`,
          boxShadow:`0 0 12px ${col}88`,
          transition:"width 1.2s cubic-bezier(.4,0,.2,1)"
        }}/>
      </div>
    </div>
  );
}

function ConfidenceArc({ value }) {
  const r = 54; const cx = 70; const cy = 70;
  const startAngle = 210; const range = 120 * 2;
  const toRad = deg => (deg*Math.PI)/180;
  const arcPath = (pct) => {
    const sweep = (range * pct)/100;
    const start = startAngle; const end = start + sweep;
    const x1 = cx + r*Math.cos(toRad(start)); const y1 = cy + r*Math.sin(toRad(start));
    const x2 = cx + r*Math.cos(toRad(end)); const y2 = cy + r*Math.sin(toRad(end));
    const la = sweep > 180 ? 1 : 0;
    return `M ${x1} ${y1} A ${r} ${r} 0 ${la} 1 ${x2} ${y2}`;
  };
  const col = value >= 80 ? "#2ed573" : value >= 60 ? "#ffa502" : "#ff4757";
  return (
    <svg width="140" height="100" viewBox="0 0 140 100">
      <path d={arcPath(100)} fill="none" stroke="#1a2235" strokeWidth="10" strokeLinecap="round"/>
      <path d={arcPath(value)} fill="none" stroke={col} strokeWidth="10" strokeLinecap="round"
        style={{filter:`drop-shadow(0 0 6px ${col})`}}/>
      <text x={cx} y={cy+10} textAnchor="middle" fill={col} fontSize="20" fontWeight="800">{value}%</text>
      <text x={cx} y={cy+26} textAnchor="middle" fill="#8892a4" fontSize="9" letterSpacing="2">CONFIDENCE</text>
    </svg>
  );
}

function DimensionRadar({ dims }) {
  const data = [
    { subject:"Timeline", value:Math.round(dims.timelinePressure*100) },
    { subject:"Budget", value:Math.round(dims.budgetConstraint*100) },
    { subject:"Experience", value:Math.round(dims.experienceRisk*100) },
    { subject:"Tech", value:Math.round(dims.technicalComplexity*100) },
  ];
  return (
    <ResponsiveContainer width="100%" height={200}>
      <RadarChart data={data}>
        <PolarGrid stroke="#1e2d45"/>
        <PolarAngleAxis dataKey="subject" tick={{fill:"#8892a4",fontSize:11}}/>
        <Radar dataKey="value" stroke="#00d2ff" fill="#00d2ff" fillOpacity={0.18}
          dot={{ r:3, fill:"#00d2ff" }}/>
      </RadarChart>
    </ResponsiveContainer>
  );
}

function CategoryPie({ distribution }) {
  const data = Object.entries(distribution).map(([name,value])=>({name,value}));
  if (!data.length) return null;
  return (
    <ResponsiveContainer width="100%" height={180}>
      <PieChart>
        <Pie data={data} cx="50%" cy="50%" innerRadius={50} outerRadius={75} paddingAngle={4} dataKey="value">
          {data.map((entry,i) => (
            <Cell key={i} fill={CAT_COLOR[entry.name]||"#555"} stroke="transparent"/>
          ))}
        </Pie>
        <Tooltip contentStyle={{background:"#0d1628",border:"1px solid #1e2d45",borderRadius:8,color:"#e0e6f0"}}/>
      </PieChart>
    </ResponsiveContainer>
  );
}

function CompareBar({ r1, r2 }) {
  if (!r1||!r2) return null;
  const data = [
    { label:"Overall", a:Math.round(r1.overallScore*100), b:Math.round(r2.overallScore*100) },
    { label:"Timeline", a:Math.round(r1.dimensions.timelinePressure*100), b:Math.round(r2.dimensions.timelinePressure*100) },
    { label:"Budget", a:Math.round(r1.dimensions.budgetConstraint*100), b:Math.round(r2.dimensions.budgetConstraint*100) },
    { label:"Experience", a:Math.round(r1.dimensions.experienceRisk*100), b:Math.round(r2.dimensions.experienceRisk*100) },
    { label:"Technical", a:Math.round(r1.dimensions.technicalComplexity*100), b:Math.round(r2.dimensions.technicalComplexity*100) },
  ];
  return (
    <ResponsiveContainer width="100%" height={230}>
      <BarChart data={data} barGap={4}>
        <CartesianGrid strokeDasharray="3 3" stroke="#1e2d45"/>
        <XAxis dataKey="label" tick={{fill:"#8892a4",fontSize:11}}/>
        <YAxis tick={{fill:"#8892a4",fontSize:11}} domain={[0,100]}/>
        <Tooltip contentStyle={{background:"#0d1628",border:"1px solid #1e2d45",borderRadius:8,color:"#e0e6f0"}}/>
        <Legend wrapperStyle={{color:"#8892a4",fontSize:12}}/>
        <Bar dataKey="a" name={r1.projectName||"Project A"} fill="#00d2ff" radius={[4,4,0,0]}/>
        <Bar dataKey="b" name={r2.projectName||"Project B"} fill="#a29bfe" radius={[4,4,0,0]}/>
      </BarChart>
    </ResponsiveContainer>
  );
}

function RiskCard({ risk, idx }) {
  const [open, setOpen] = useState(false);
  const col = SEV_COLOR[risk.severity];
  return (
    <div style={{
      background:"#0d1628", border:`1px solid ${open?"#1e3a5f":"#1a2235"}`,
      borderLeft:`3px solid ${col}`, borderRadius:10, marginBottom:10,
      overflow:"hidden", transition:"border-color .2s"
    }}>
      <div style={{ padding:"14px 18px", cursor:"pointer", display:"flex", alignItems:"center", gap:12 }}
        onClick={() => setOpen(v=>!v)}>
        <span style={{ background:`${col}18`, color:col, borderRadius:6, padding:"4px 8px",
          fontSize:10, fontWeight:700, letterSpacing:1, minWidth:64, textAlign:"center" }}>
          {risk.id}
        </span>
        <div style={{flex:1}}>
          <div style={{fontWeight:600,color:"#e0e6f0",fontSize:14}}>{risk.title}</div>
          <div style={{fontSize:11,color:"#8892a4",marginTop:2}}>{risk.category}</div>
        </div>
        <div style={{display:"flex",gap:12,alignItems:"center"}}>
          <SeverityBadge level={risk.severity}/>
          <div style={{textAlign:"right",fontSize:11,color:"#8892a4"}}>
            <div>P:{(risk.probability*100).toFixed(0)}% I:{(risk.impact*100).toFixed(0)}%</div>
            <div style={{color:"#5f8ab0",marginTop:1}}>Conf:{risk.confidence}%</div>
          </div>
          <span style={{color:"#8892a4",fontSize:16,transform:open?"rotate(180deg)":"none",transition:".2s"}}>▾</span>
        </div>
      </div>
      {open && (
        <div style={{padding:"0 18px 16px",borderTop:"1px solid #1a2235"}}>
          <div style={{marginTop:12,background:"#0a1020",borderRadius:8,padding:"10px 14px",
            borderLeft:`2px solid ${col}44`,fontSize:13,color:"#b0bec5",lineHeight:1.7}}>
            <span style={{color:col,fontWeight:600}}>⚡ Why: </span>{risk.explanation}
          </div>
          <div style={{marginTop:12}}>
            <div style={{fontSize:11,fontWeight:700,color:"#5f8ab0",letterSpacing:1,marginBottom:8}}>MITIGATION STRATEGIES</div>
            {risk.mitigation.map((m,i) => (
              <div key={i} style={{display:"flex",gap:10,marginBottom:6,fontSize:12,color:"#b0bec5",alignItems:"flex-start"}}>
                <span style={{color:"#2ed573",marginTop:2,flexShrink:0}}>→</span>{m}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function FormSelect({ label, field, options, form, setForm }) {
  return (
    <div style={{display:"flex",flexDirection:"column",gap:4}}>
      <label style={{fontSize:11,color:"#5f8ab0",letterSpacing:1,textTransform:"uppercase",fontWeight:600}}>{label}</label>
      <select value={form[field]} onChange={e=>setForm(f=>({...f,[field]:e.target.value}))}
        style={{background:"#0a1020",border:"1px solid #1e2d45",borderRadius:7,color:"#e0e6f0",
          padding:"9px 12px",fontSize:13,outline:"none",cursor:"pointer",
          transition:"border-color .2s"}}
        onFocus={e=>e.target.style.borderColor="#00d2ff"}
        onBlur={e=>e.target.style.borderColor="#1e2d45"}>
        {options.map(o=><option key={o} value={o}>{o}</option>)}
      </select>
    </div>
  );
}

function FormInput({ label, field, type="text", min, max, form, setForm }) {
  return (
    <div style={{display:"flex",flexDirection:"column",gap:4}}>
      <label style={{fontSize:11,color:"#5f8ab0",letterSpacing:1,textTransform:"uppercase",fontWeight:600}}>{label}</label>
      <input type={type} min={min} max={max} value={form[field]}
        onChange={e=>setForm(f=>({...f,[field]:type==="number"?Number(e.target.value):e.target.value}))}
        style={{background:"#0a1020",border:"1px solid #1e2d45",borderRadius:7,color:"#e0e6f0",
          padding:"9px 12px",fontSize:13,outline:"none",transition:"border-color .2s"}}
        onFocus={e=>e.target.style.borderColor="#00d2ff"}
        onBlur={e=>e.target.style.borderColor="#1e2d45"}/>
    </div>
  );
}

// ── Main App ───────────────────────────────────────────────────────────────

export default function App() {
  const [tab, setTab] = useState("analyze"); // analyze | compare
  const [formA, setFormA] = useState({...DEFAULT_FORM, projectName:"Alpha Project"});
  const [formB, setFormB] = useState({...DEFAULT_FORM, projectName:"Beta Project",
    durationWeeks:6, budgetUSD:15000, teamSize:2, teamExperience:"junior",
    techStack:"blockchain", deadlineStrictness:"critical", domain:"ai-ml"});
  const [resultA, setResultA] = useState(null);
  const [resultB, setResultB] = useState(null);
  const [loading, setLoading] = useState(false);
  const [activeResult, setActiveResult] = useState(null);
  const [filterSev, setFilterSev] = useState("All");
  const [aiInsight, setAiInsight] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const dashRef = useRef(null);

  const runAnalysis = async (form, setter, activate=true) => {
    setLoading(true);
    await new Promise(r => setTimeout(r, 900)); // UX delay for realism
    const result = analyzeProject(form);
    setter(result);
    if (activate) setActiveResult(result);
    setLoading(false);
  };

  const getAiInsight = async (report) => {
    setAiLoading(true); setAiInsight("");
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body: JSON.stringify({
          model:"claude-sonnet-4-20250514", max_tokens:500,
          messages:[{role:"user", content:
            `You are an expert project risk analyst. Given this risk analysis report, provide a sharp 3-4 sentence executive insight highlighting the most critical concern, the root cause, and the single most important action to take immediately. Be direct, specific, and use data from the report.\n\nReport: ${JSON.stringify({
              projectName:report.projectName, overallScore:report.overallScore,
              overallSeverity:report.overallSeverity, riskCount:report.riskCount,
              topRisks:report.risks.slice(0,3).map(r=>({title:r.title,severity:r.severity,explanation:r.explanation})),
              dimensions:report.dimensions
            })}`
          }]
        })
      });
      const data = await res.json();
      const text = data.content?.map(c=>c.text||"").join("") || "Unable to generate insight.";
      setAiInsight(text);
    } catch { setAiInsight("AI insight unavailable. Check API connection."); }
    setAiLoading(false);
  };

  const sevCounts = activeResult ? {
    High: activeResult.risks.filter(r=>r.severity==="High").length,
    Medium: activeResult.risks.filter(r=>r.severity==="Medium").length,
    Low: activeResult.risks.filter(r=>r.severity==="Low").length,
  } : null;

  const filteredRisks = activeResult?.risks.filter(r => filterSev==="All" || r.severity===filterSev) || [];

  const s = {
    app: { minHeight:"100vh", background:"#060d1a", fontFamily:"'IBM Plex Mono', 'Fira Code', monospace", color:"#e0e6f0", padding:"0 0 60px" },
    nav: { background:"#080f1e", borderBottom:"1px solid #1a2235", padding:"0 32px", display:"flex", alignItems:"center", gap:24, height:56, position:"sticky", top:0, zIndex:100 },
    logo: { color:"#00d2ff", fontWeight:800, fontSize:16, letterSpacing:2, marginRight:16 },
    navTab: (active) => ({ padding:"0 16px", height:"100%", display:"flex", alignItems:"center", fontSize:12, letterSpacing:1, cursor:"pointer", borderBottom:`2px solid ${active?"#00d2ff":"transparent"}`, color:active?"#00d2ff":"#8892a4", textTransform:"uppercase", fontWeight:600, transition:"all .2s" }),
    main: { maxWidth:1200, margin:"0 auto", padding:"32px 24px" },
    grid: { display:"grid", gridTemplateColumns:"380px 1fr", gap:24, alignItems:"start" },
    card: { background:"#0d1628", border:"1px solid #1a2235", borderRadius:14, padding:24 },
    cardTitle: { fontSize:11, letterSpacing:2, color:"#5f8ab0", textTransform:"uppercase", fontWeight:700, marginBottom:18, display:"flex", alignItems:"center", gap:8 },
    btn: (col="#00d2ff",full=false) => ({ background:`linear-gradient(135deg,${col}22,${col}11)`, border:`1px solid ${col}55`, color:col, borderRadius:8, padding:"11px 22px", fontSize:12, fontWeight:700, letterSpacing:1, cursor:"pointer", textTransform:"uppercase", transition:"all .2s", width:full?"100%":"auto" }),
    statBox: (col) => ({ background:`${col}0e`, border:`1px solid ${col}33`, borderRadius:10, padding:"12px 16px", textAlign:"center" }),
  };

  return (
    <div style={s.app}>
      {/* ── Nav ── */}
      <nav style={s.nav}>
        <span style={s.logo}>⬡ RISKIQ</span>
        <div style={{display:"flex",height:"100%"}}>
          {[["analyze","Analyze"],["compare","Compare"]].map(([k,l]) => (
            <div key={k} style={s.navTab(tab===k)} onClick={()=>setTab(k)}>{l}</div>
          ))}
        </div>
        <div style={{marginLeft:"auto",fontSize:11,color:"#1e3a5f"}}>PROJECT RISK ANALYSIS ENGINE v1.0</div>
      </nav>

      <div style={s.main}>
        {/* ── ANALYZE TAB ── */}
        {tab === "analyze" && (
          <div style={s.grid}>
            {/* Form Panel */}
            <div>
              <div style={s.card}>
                <div style={s.cardTitle}>⬡ Project Parameters</div>
                <div style={{display:"flex",flexDirection:"column",gap:14}}>
                  <FormInput label="Project Name" field="projectName" form={formA} setForm={setFormA}/>
                  <FormSelect label="Domain" field="domain" options={DOMAINS} form={formA} setForm={setFormA}/>
                  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
                    <FormInput label="Duration (Weeks)" field="durationWeeks" type="number" min={1} max={260} form={formA} setForm={setFormA}/>
                    <FormInput label="Budget (USD)" field="budgetUSD" type="number" min={0} form={formA} setForm={setFormA}/>
                    <FormInput label="Team Size" field="teamSize" type="number" min={1} max={500} form={formA} setForm={setFormA}/>
                    <FormSelect label="Experience" field="teamExperience" options={EXPERIENCES} form={formA} setForm={setFormA}/>
                  </div>
                  <FormSelect label="Tech Stack" field="techStack" options={STACKS} form={formA} setForm={setFormA}/>
                  <FormSelect label="Deadline Strictness" field="deadlineStrictness" options={DEADLINES} form={formA} setForm={setFormA}/>
                  <button style={s.btn("#00d2ff",true)} onClick={()=>runAnalysis(formA,setResultA)}
                    onMouseEnter={e=>{e.target.style.background="linear-gradient(135deg,#00d2ff33,#00d2ff22)";e.target.style.borderColor="#00d2ff"}}
                    onMouseLeave={e=>{e.target.style.background="linear-gradient(135deg,#00d2ff22,#00d2ff11)";e.target.style.borderColor="#00d2ff55"}}>
                    {loading ? "◌ Analyzing…" : "⬡ Run Risk Analysis"}
                  </button>
                </div>
              </div>

              {resultA && (
                <div style={{...s.card, marginTop:20}}>
                  <div style={s.cardTitle}>◈ Dimension Radar</div>
                  <DimensionRadar dims={resultA.dimensions}/>
                  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginTop:12}}>
                    {Object.entries(resultA.dimensions).map(([k,v]) => (
                      <div key={k} style={{background:"#0a1020",borderRadius:8,padding:"8px 12px"}}>
                        <div style={{fontSize:10,color:"#5f8ab0",textTransform:"uppercase",letterSpacing:1}}>{k.replace(/([A-Z])/g," $1").trim()}</div>
                        <div style={{fontSize:18,fontWeight:800,color:"#00d2ff",marginTop:2}}>{(v*100).toFixed(0)}<span style={{fontSize:11,color:"#5f8ab0"}}>%</span></div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Dashboard Panel */}
            <div ref={dashRef}>
              {!resultA && !loading && (
                <div style={{...s.card, textAlign:"center", padding:"60px 32px"}}>
                  <div style={{fontSize:48,marginBottom:16}}>⬡</div>
                  <div style={{fontSize:18,color:"#5f8ab0",fontWeight:600}}>Configure your project</div>
                  <div style={{fontSize:13,color:"#1e3a5f",marginTop:8}}>Set parameters and run analysis to see your risk profile</div>
                </div>
              )}

              {loading && (
                <div style={{...s.card, textAlign:"center", padding:"60px 32px"}}>
                  <div style={{fontSize:32,color:"#00d2ff",animation:"spin 1s linear infinite",display:"inline-block"}}>◌</div>
                  <div style={{fontSize:14,color:"#5f8ab0",marginTop:16}}>Running heuristic analysis engine…</div>
                  <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>
                </div>
              )}

              {resultA && !loading && (
                <>
                  {/* Header stats */}
                  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr 1fr",gap:14,marginBottom:20}}>
                    {[
                      { label:"OVERALL SCORE", value:<GlowNumber value={resultA.overallScore*100} suffix="%" decimals={1}/>, sub:resultA.overallSeverity, col:SEV_COLOR[resultA.overallSeverity] },
                      { label:"RISKS DETECTED", value:<GlowNumber value={resultA.riskCount} suffix="" decimals={0} color="#ffa502"/>, sub:"factors", col:"#ffa502" },
                      { label:"CONFIDENCE", value:<GlowNumber value={resultA.overallConfidence} suffix="%" decimals={0} color="#a29bfe"/>, sub:"AI confidence", col:"#a29bfe" },
                      { label:"HIGH SEVERITY", value:<GlowNumber value={resultA.risks.filter(r=>r.severity==="High").length} suffix="" decimals={0} color="#ff4757"/>, sub:"critical risks", col:"#ff4757" },
                    ].map((s2,i) => (
                      <div key={i} style={{background:"#0d1628",border:`1px solid #1a2235`,borderRadius:12,padding:"16px 18px"}}>
                        <div style={{fontSize:9,letterSpacing:2,color:"#5f8ab0",marginBottom:8}}>{s2.label}</div>
                        <div style={{fontSize:26,fontWeight:800}}>{s2.value}</div>
                        <div style={{fontSize:11,color:s2.col,marginTop:4,textTransform:"uppercase",letterSpacing:1}}>{s2.sub}</div>
                      </div>
                    ))}
                  </div>

                  {/* Score meter + confidence + summary */}
                  <div style={{...s.card, marginBottom:20}}>
                    <div style={{display:"grid",gridTemplateColumns:"1fr auto",gap:24,alignItems:"center"}}>
                      <div>
                        <div style={{...s.cardTitle, marginBottom:12}}>⬡ {resultA.projectName}</div>
                        <RiskMeter score={resultA.overallScore}/>
                        <div style={{fontSize:12,color:"#8892a4",marginTop:14,lineHeight:1.7,borderLeft:"2px solid #1e3a5f",paddingLeft:12}}>
                          {resultA.summary}
                        </div>
                      </div>
                      <ConfidenceArc value={resultA.overallConfidence}/>
                    </div>
                  </div>

                  {/* Category distribution + pie */}
                  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14,marginBottom:20}}>
                    <div style={s.card}>
                      <div style={s.cardTitle}>◈ Category Distribution</div>
                      <CategoryPie distribution={resultA.categoryDistribution}/>
                      <div style={{display:"flex",flexWrap:"wrap",gap:6,marginTop:8}}>
                        {Object.entries(resultA.categoryDistribution).map(([cat,cnt]) => (
                          <span key={cat} style={{background:`${CAT_COLOR[cat]||"#555"}18`,border:`1px solid ${CAT_COLOR[cat]||"#555"}44`,
                            color:CAT_COLOR[cat]||"#aaa",borderRadius:6,padding:"3px 10px",fontSize:11,fontWeight:600}}>
                            {cat}: {cnt}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div style={s.card}>
                      <div style={s.cardTitle}>◈ Severity Breakdown</div>
                      <div style={{display:"flex",flexDirection:"column",gap:10,marginTop:8}}>
                        {["High","Medium","Low"].map(sev => {
                          const cnt = resultA.risks.filter(r=>r.severity===sev).length;
                          const pct = resultA.riskCount > 0 ? (cnt/resultA.riskCount*100) : 0;
                          const col = SEV_COLOR[sev];
                          return (
                            <div key={sev}>
                              <div style={{display:"flex",justifyContent:"space-between",fontSize:12,marginBottom:4}}>
                                <span style={{color:col}}>{sev}</span><span style={{color:"#8892a4"}}>{cnt} risks</span>
                              </div>
                              <div style={{background:"#0a1020",borderRadius:6,height:8}}>
                                <div style={{width:`${pct}%`,height:"100%",background:`linear-gradient(90deg,${col}88,${col})`,borderRadius:6,boxShadow:`0 0 8px ${col}66`,transition:"width 1s ease"}}/>
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      {/* AI Insight */}
                      <div style={{marginTop:18}}>
                        <button style={s.btn("#a29bfe",true)} onClick={()=>getAiInsight(resultA)}
                          onMouseEnter={e=>e.target.style.background="linear-gradient(135deg,#a29bfe33,#a29bfe22)"}
                          onMouseLeave={e=>e.target.style.background="linear-gradient(135deg,#a29bfe22,#a29bfe11)"}>
                          {aiLoading ? "◌ Generating…" : "⬡ Get AI Executive Insight"}
                        </button>
                        {aiInsight && (
                          <div style={{marginTop:12,background:"#0a0f1e",borderRadius:8,padding:"12px 14px",
                            border:"1px solid #a29bfe33",fontSize:12,color:"#b0bec5",lineHeight:1.8}}>
                            <span style={{color:"#a29bfe",fontWeight:700}}>AI INSIGHT: </span>{aiInsight}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Risk list */}
                  <div style={s.card}>
                    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:16}}>
                      <div style={s.cardTitle}>◈ Risk Register ({filteredRisks.length})</div>
                      <div style={{display:"flex",gap:8}}>
                        {["All","High","Medium","Low"].map(f => (
                          <button key={f} onClick={()=>setFilterSev(f)}
                            style={{...s.btn(filterSev===f?(f==="All"?"#00d2ff":SEV_COLOR[f]):"#2a3a55"),
                              padding:"5px 12px",fontSize:10}}>
                            {f}
                          </button>
                        ))}
                      </div>
                    </div>
                    {filteredRisks.length === 0
                      ? <div style={{color:"#5f8ab0",fontSize:13,textAlign:"center",padding:"20px 0"}}>No risks at this severity level.</div>
                      : filteredRisks.map((r,i)=><RiskCard key={r.id} risk={r} idx={i}/>)
                    }
                  </div>
                </>
              )}
            </div>
          </div>
        )}

        {/* ── COMPARE TAB ── */}
        {tab === "compare" && (
          <div>
            <div style={{fontSize:11,color:"#5f8ab0",letterSpacing:2,textTransform:"uppercase",marginBottom:24}}>
              ◈ Side-by-Side Scenario Comparison
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:20,marginBottom:24}}>
              {[[formA,setFormA,resultA,"Alpha","#00d2ff"],[formB,setFormB,resultB,"Beta","#a29bfe"]].map(([form,setForm,result,label,col],idx)=>(
                <div key={idx} style={s.card}>
                  <div style={{...s.cardTitle, color:col}}>⬡ Project {label}</div>
                  <div style={{display:"flex",flexDirection:"column",gap:10}}>
                    <FormInput label="Project Name" field="projectName" form={form} setForm={setForm}/>
                    <FormSelect label="Domain" field="domain" options={DOMAINS} form={form} setForm={setForm}/>
                    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                      <FormInput label="Duration (w)" field="durationWeeks" type="number" min={1} form={form} setForm={setForm}/>
                      <FormInput label="Budget ($)" field="budgetUSD" type="number" min={0} form={form} setForm={setForm}/>
                      <FormInput label="Team Size" field="teamSize" type="number" min={1} form={form} setForm={setForm}/>
                      <FormSelect label="Experience" field="teamExperience" options={EXPERIENCES} form={form} setForm={setForm}/>
                    </div>
                    <FormSelect label="Tech Stack" field="techStack" options={STACKS} form={form} setForm={setForm}/>
                    <FormSelect label="Deadline" field="deadlineStrictness" options={DEADLINES} form={form} setForm={setForm}/>
                    <button style={s.btn(col,true)}
                      onClick={()=>idx===0?runAnalysis(formA,setResultA,false):runAnalysis(formB,setResultB,false)}>
                      ⬡ Analyze
                    </button>
                    {result && (
                      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginTop:4}}>
                        <div style={s.statBox(SEV_COLOR[result.overallSeverity])}>
                          <div style={{fontSize:9,color:"#5f8ab0",marginBottom:4,letterSpacing:1}}>SCORE</div>
                          <div style={{fontSize:20,fontWeight:800,color:SEV_COLOR[result.overallSeverity]}}>{(result.overallScore*100).toFixed(0)}%</div>
                        </div>
                        <div style={s.statBox("#ffa502")}>
                          <div style={{fontSize:9,color:"#5f8ab0",marginBottom:4,letterSpacing:1}}>RISKS</div>
                          <div style={{fontSize:20,fontWeight:800,color:"#ffa502"}}>{result.riskCount}</div>
                        </div>
                        <div style={s.statBox(col)}>
                          <div style={{fontSize:9,color:"#5f8ab0",marginBottom:4,letterSpacing:1}}>CONF</div>
                          <div style={{fontSize:20,fontWeight:800,color:col}}>{result.overallConfidence}%</div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {resultA && resultB && (
              <>
                <div style={{...s.card, marginBottom:20}}>
                  <div style={s.cardTitle}>◈ Risk Dimension Comparison</div>
                  <CompareBar r1={resultA} r2={resultB}/>
                </div>

                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:20}}>
                  {[resultA,resultB].map((r,i) => (
                    <div key={i} style={s.card}>
                      <div style={{...s.cardTitle, color:i===0?"#00d2ff":"#a29bfe"}}>{r.projectName} — Top Risks</div>
                      {r.risks.filter(x=>x.severity==="High").slice(0,3).map(risk=>(
                        <div key={risk.id} style={{display:"flex",gap:10,alignItems:"center",marginBottom:8,
                          background:"#0a1020",borderRadius:8,padding:"10px 12px",
                          borderLeft:`2px solid ${SEV_COLOR[risk.severity]}`}}>
                          <SeverityBadge level={risk.severity}/>
                          <div style={{flex:1}}>
                            <div style={{fontSize:12,color:"#e0e6f0",fontWeight:600}}>{risk.title}</div>
                            <div style={{fontSize:10,color:"#8892a4"}}>{risk.category} • P:{(risk.probability*100).toFixed(0)}%</div>
                          </div>
                        </div>
                      ))}
                      {r.risks.filter(x=>x.severity==="High").length===0 && (
                        <div style={{color:"#2ed573",fontSize:12}}>✓ No high severity risks detected</div>
                      )}
                    </div>
                  ))}
                </div>
              </>
            )}

            {(!resultA || !resultB) && (
              <div style={{...s.card, textAlign:"center",padding:"40px"}}>
                <div style={{color:"#5f8ab0",fontSize:13}}>Analyze both projects to see comparison charts</div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
