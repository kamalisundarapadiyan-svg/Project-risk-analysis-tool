/**
 * routes/analyze.js
 * Defines POST /analyze — validates input and delegates to the risk engine.
 */

const express = require("express");
const router = express.Router();
const { validateInput } = require("../utils/validator");
const { runRiskEngine } = require("../services/riskEngine");

/**
 * POST /api/analyze
 * Body: ProjectInput (see validator for schema)
 * Returns: RiskAnalysisReport
 */
router.post("/analyze", (req, res) => {
  const { error, value } = validateInput(req.body);

  if (error) {
    return res.status(400).json({
      success: false,
      error: "Invalid input",
      details: error,
    });
  }

  try {
    const report = runRiskEngine(value);
    return res.status(200).json({ success: true, data: report });
  } catch (err) {
    console.error("Risk Engine Error:", err);
    return res.status(500).json({ success: false, error: "Analysis failed" });
  }
});

module.exports = router;
