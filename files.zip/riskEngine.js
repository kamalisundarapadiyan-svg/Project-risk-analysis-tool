/**
 * services/riskEngine.js
 * ─────────────────────────────────────────────────────────────────────────
 * The AI-like heuristic risk engine.
 *
 * Architecture:
 *   1. Decompose project inputs into four pressure dimensions.
 *   2. Run each RiskDetector against those dimensions.
 *   3. Aggregate per-risk scores into an overall project risk profile.
 *   4. Return a structured RiskAnalysisReport with full explanations.
 */

const {
  timelinePressure,
  budgetConstraint,
  experienceRisk,
  technicalComplexity,
  compositeRiskScore,
  severityLabel,
  confidenceScore,
} = require("../utils/scoring");

// ── Risk Detector Definitions ──────────────────────────────────────────────
// Each detector is a pure function:
//   (dims, input) → RiskItem | null
//
// dims = { t, b, e, x, teamSize, durationWeeks, budgetUSD, teamExperience, techStack, deadlineStrictness }

const RISK_DETECTORS = [
  // ── Schedule Risk ──────────────────────────────────────────────────────
  {
    id: "SCH-001",
    category: "Schedule",
    title: "Tight Timeline Pressure",
    detect(dims) {
      if (dims.t < 0.4) return null; // not triggered
      const prob   = Math.min(0.95, 0.4 + dims.t * 0.55);
      const impact = Math.min(0.95, 0.3 + dims.t * 0.6);
      const score  = (prob + impact) / 2;
      return {
        probability: prob,
        impact,
        score,
        severity: severityLabel(score),
        confidence: Math.round(60 + dims.t * 35),
        explanation: `Project duration of ${dims.durationWeeks} week(s) combined with a "${dims.deadlineStrictness}" deadline leaves minimal buffer for delays. Timeline pressure index: ${(dims.t * 100).toFixed(0)}%.`,
        mitigation: [
          "Break deliverables into 2-week sprints with clear milestones.",
          "Implement a risk buffer of 15–20% on each phase.",
          "Prioritise an MVP scope and negotiate non-critical features.",
          "Introduce automated CI/CD to reduce deployment overhead.",
        ],
      };
    },
  },

  // ── Schedule: Deadline Crunch ──────────────────────────────────────────
  {
    id: "SCH-002",
    category: "Schedule",
    title: "Critical Deadline Crunch",
    detect(dims) {
      if (dims.deadlineStrictness !== "critical" && dims.deadlineStrictness !== "strict") return null;
      if (dims.durationWeeks > 16) return null;
      const prob   = 0.85;
      const impact = 0.9;
      const score  = 0.87;
      return {
        probability: prob,
        impact,
        score,
        severity: "High",
        confidence: 91,
        explanation: `A ${dims.deadlineStrictness} deadline with only ${dims.durationWeeks} weeks is a classic recipe for crunch, technical debt accumulation, and burnout.`,
        mitigation: [
          "Escalate scope-reduction discussion with stakeholders immediately.",
          "Define a hard feature-freeze date at 80% of the timeline.",
          "Introduce daily standups to detect blockers within 24 hours.",
        ],
      };
    },
  },

  // ── Cost Risk ──────────────────────────────────────────────────────────
  {
    id: "CST-001",
    category: "Cost",
    title: "Budget Constraint & Overrun Risk",
    detect(dims) {
      if (dims.b < 0.35) return null;
      const prob   = Math.min(0.93, 0.3 + dims.b * 0.65);
      const impact = Math.min(0.9,  0.25 + dims.b * 0.6);
      const score  = (prob + impact) / 2;
      const perMember = Math.round(dims.budgetUSD / Math.max(dims.teamSize, 1));
      return {
        probability: prob,
        impact,
        score,
        severity: severityLabel(score),
        confidence: Math.round(55 + dims.b * 38),
        explanation: `Budget of $${dims.budgetUSD.toLocaleString()} across ${dims.teamSize} member(s) yields ~$${perMember.toLocaleString()} per person — below the comfortable threshold for sustained project delivery. Budget pressure index: ${(dims.b * 100).toFixed(0)}%.`,
        mitigation: [
          "Introduce weekly budget burn-rate tracking.",
          "Consider open-source tooling to reduce licensing costs.",
          "Negotiate phased payment milestones to maintain cash flow.",
          "Reserve a contingency fund of 10–15% of total budget.",
        ],
      };
    },
  },

  // ── Technical Risk ─────────────────────────────────────────────────────
  {
    id: "TCH-001",
    category: "Technical",
    title: "Technology Complexity vs. Team Capability",
    detect(dims) {
      if (dims.x < 0.3 && dims.e < 0.3) return null;
      const combinedRisk = (dims.x * 0.55) + (dims.e * 0.45);
      if (combinedRisk < 0.3) return null;
      const prob   = Math.min(0.92, combinedRisk * 1.1);
      const impact = Math.min(0.9, combinedRisk * 1.05);
      const score  = (prob + impact) / 2;
      return {
        probability: prob,
        impact,
        score,
        severity: severityLabel(score),
        confidence: Math.round(58 + combinedRisk * 35),
        explanation: `The "${dims.techStack}" stack has a complexity index of ${(dims.x * 100).toFixed(0)}% while the team's experience level ("${dims.teamExperience}") introduces a skill-gap risk of ${(dims.e * 100).toFixed(0)}%. Combined, this creates significant probability of architectural mistakes and rework.`,
        mitigation: [
          "Assign a technical lead or architect to own design decisions.",
          "Schedule a technology spike (proof-of-concept) in Week 1.",
          "Establish coding standards, peer review, and a lint pipeline.",
          "Invest in targeted upskilling sessions on the chosen stack.",
        ],
      };
    },
  },

  // ── Technical: High Complexity Domain ─────────────────────────────────
  {
    id: "TCH-002",
    category: "Technical",
    title: "Domain-Specific Technical Uncertainty",
    detect(dims) {
      const highComplexDomains = ["ai-ml", "cybersecurity", "blockchain", "iot", "embedded"];
      if (!highComplexDomains.includes(dims.domain)) return null;
      const prob   = 0.72;
      const impact = 0.78;
      const score  = 0.75;
      return {
        probability: prob,
        impact,
        score,
        severity: "High",
        confidence: 82,
        explanation: `The "${dims.domain}" domain inherently carries unknown-unknowns: regulatory constraints, hardware dependencies, model instability, or security vulnerabilities that are hard to estimate at project outset.`,
        mitigation: [
          "Conduct a domain risk-assessment workshop in Week 1.",
          "Identify and consult domain SMEs (Subject Matter Experts).",
          "Build in a research/exploration phase before implementation.",
          "Document all assumptions and validate them early.",
        ],
      };
    },
  },

  // ── Resource Risk ──────────────────────────────────────────────────────
  {
    id: "RES-001",
    category: "Resource",
    title: "Understaffing & Key-Person Dependency",
    detect(dims) {
      if (dims.teamSize > 4) return null;
      const smallnessScore = Math.max(0, (5 - dims.teamSize) / 4);
      const prob   = Math.min(0.9, 0.4 + smallnessScore * 0.5);
      const impact = Math.min(0.88, 0.45 + smallnessScore * 0.4);
      const score  = (prob + impact) / 2;
      return {
        probability: prob,
        impact,
        score,
        severity: severityLabel(score),
        confidence: Math.round(65 + smallnessScore * 25),
        explanation: `A team of ${dims.teamSize} person(s) creates high key-person dependency. Any absence, illness, or attrition directly threatens delivery. With ${dims.teamSize <= 2 ? "1–2" : "3–4"} people, there is no redundancy for critical skills.`,
        mitigation: [
          "Document all decisions and maintain a shared knowledge base.",
          "Cross-train team members on each other's domains.",
          "Identify external contractors for emergency cover.",
          "Define an absence-response plan before development starts.",
        ],
      };
    },
  },

  // ── Resource: Overload ─────────────────────────────────────────────────
  {
    id: "RES-002",
    category: "Resource",
    title: "Team Overload & Burnout Risk",
    detect(dims) {
      // High pressure + small-medium team
      if (dims.teamSize > 8 || dims.t < 0.55) return null;
      const prob   = Math.min(0.88, 0.45 + dims.t * 0.45);
      const impact = 0.65;
      const score  = (prob + impact) / 2;
      return {
        probability: prob,
        impact,
        score,
        severity: severityLabel(score),
        confidence: 72,
        explanation: `High timeline pressure (${(dims.t * 100).toFixed(0)}%) distributed across ${dims.teamSize} team member(s) predicts unsustainable working hours, increasing burnout probability and reducing output quality over time.`,
        mitigation: [
          "Enforce a sustainable pace policy (max 45h/week).",
          "Rotate on-call and high-pressure tasks weekly.",
          "Schedule a mid-project retrospective to assess team health.",
          "Escalate resourcing needs to management proactively.",
        ],
      };
    },
  },

  // ── Communication Risk ─────────────────────────────────────────────────
  {
    id: "COM-001",
    category: "Communication",
    title: "Large Team Coordination Overhead",
    detect(dims) {
      if (dims.teamSize < 10) return null;
      // Brooks's Law: communication channels = n(n-1)/2
      const channels = (dims.teamSize * (dims.teamSize - 1)) / 2;
      const overheadScore = Math.min(1, channels / 200);
      const prob   = Math.min(0.88, 0.45 + overheadScore * 0.4);
      const impact = Math.min(0.8, 0.4 + overheadScore * 0.35);
      const score  = (prob + impact) / 2;
      return {
        probability: prob,
        impact,
        score,
        severity: severityLabel(score),
        confidence: Math.round(65 + overheadScore * 25),
        explanation: `A team of ${dims.teamSize} creates ${channels} potential communication channels (Brook's Law). Without formal coordination structures, misalignment, duplicated effort, and integration failures become increasingly likely.`,
        mitigation: [
          "Adopt a squad/chapter model (teams of 5–7 max).",
          "Designate a project coordinator / scrum master.",
          "Use async communication tools (Confluence, Notion) for documentation.",
          "Hold cross-team syncs no more than twice weekly to limit overhead.",
        ],
      };
    },
  },

  // ── Communication: Experience Misalignment ─────────────────────────────
  {
    id: "COM-002",
    category: "Communication",
    title: "Mixed Experience Communication Gap",
    detect(dims) {
      if (dims.teamExperience !== "mixed") return null;
      const prob   = 0.6;
      const impact = 0.55;
      const score  = 0.575;
      return {
        probability: prob,
        impact,
        score,
        severity: "Medium",
        confidence: 68,
        explanation: `A mixed-experience team introduces communication friction between senior and junior members: differing assumptions about process, quality standards, and technical vocabulary slow down collaboration.`,
        mitigation: [
          "Create a team glossary and onboarding guide.",
          "Pair junior members with seniors via a buddy system.",
          "Standardise code review language and feedback culture.",
          "Run a team-norms workshop in the first week.",
        ],
      };
    },
  },
];

// ── Risk Engine ────────────────────────────────────────────────────────────

/**
 * Runs the full risk analysis pipeline.
 * @param {object} input - validated project input
 * @returns {RiskAnalysisReport}
 */
function runRiskEngine(input) {
  const { durationWeeks, budgetUSD, teamSize, teamExperience, techStack, domain, deadlineStrictness } = input;

  // ── Step 1: Compute pressure dimensions ────────────────────────────────
  const t = timelinePressure(durationWeeks, deadlineStrictness);
  const b = budgetConstraint(budgetUSD, teamSize);
  const e = experienceRisk(teamExperience);
  const x = technicalComplexity(techStack, domain);

  const dims = { t, b, e, x, ...input };

  // ── Step 2: Run detectors ───────────────────────────────────────────────
  const detectedRisks = [];
  for (const detector of RISK_DETECTORS) {
    const result = detector.detect(dims);
    if (result) {
      detectedRisks.push({
        id:          detector.id,
        category:    detector.category,
        title:       detector.title,
        severity:    result.severity,
        probability: parseFloat(result.probability.toFixed(3)),
        impact:      parseFloat(result.impact.toFixed(3)),
        score:       parseFloat(result.score.toFixed(3)),
        confidence:  result.confidence,
        explanation: result.explanation,
        mitigation:  result.mitigation,
      });
    }
  }

  // ── Step 3: Aggregate overall score ────────────────────────────────────
  const overallScore = parseFloat(
    compositeRiskScore(t, b, e, x).toFixed(3)
  );
  const overallSeverity   = severityLabel(overallScore);
  const overallConfidence = Math.round(confidenceScore(t, b, e, x));

  // Category distribution
  const categoryCount = {};
  detectedRisks.forEach(({ category }) => {
    categoryCount[category] = (categoryCount[category] || 0) + 1;
  });

  // ── Step 4: Return structured report ───────────────────────────────────
  return {
    projectName:    input.projectName,
    analysedAt:     new Date().toISOString(),
    overallScore,          // 0–1
    overallSeverity,       // Low / Medium / High
    overallConfidence,     // 0–100
    riskCount:      detectedRisks.length,
    dimensions: {
      timelinePressure:     parseFloat(t.toFixed(3)),
      budgetConstraint:     parseFloat(b.toFixed(3)),
      experienceRisk:       parseFloat(e.toFixed(3)),
      technicalComplexity:  parseFloat(x.toFixed(3)),
    },
    categoryDistribution: categoryCount,
    risks: detectedRisks,
    summary: buildSummary(overallSeverity, overallScore, detectedRisks, input),
  };
}

/**
 * Generates a human-readable executive summary paragraph.
 */
function buildSummary(severity, score, risks, input) {
  const highRisks = risks.filter((r) => r.severity === "High").map((r) => r.title);
  const topCategories = [...new Set(risks.map((r) => r.category))].slice(0, 3);

  return (
    `Project "${input.projectName}" has been assessed as ${severity.toUpperCase()} risk ` +
    `(composite score: ${(score * 100).toFixed(1)}%). ` +
    `${risks.length} risk factor(s) were identified across ${topCategories.join(", ")} domains. ` +
    (highRisks.length
      ? `Critical concerns include: ${highRisks.join("; ")}. Immediate mitigation is recommended.`
      : `No critical risk factors detected. Maintain monitoring throughout delivery.`)
  );
}

module.exports = { runRiskEngine };
