/**
 * tests/riskEngine.test.js
 * Unit tests for the Project Risk Analysis Engine.
 * Run: npm test
 */

const request = require("supertest");
const app = require("../server");
const { runRiskEngine } = require("../services/riskEngine");
const { validateInput } = require("../utils/validator");

// ── Test Fixtures ──────────────────────────────────────────────────────────

const HIGH_RISK_INPUT = {
  projectName:        "CriticalLaunch",
  domain:             "blockchain",
  durationWeeks:      4,
  budgetUSD:          10000,
  teamSize:           2,
  teamExperience:     "junior",
  techStack:          "rust",
  deadlineStrictness: "critical",
};

const LOW_RISK_INPUT = {
  projectName:        "SimpleWebsite",
  domain:             "web",
  durationWeeks:      52,
  budgetUSD:          500000,
  teamSize:           6,
  teamExperience:     "senior",
  techStack:          "react",
  deadlineStrictness: "flexible",
};

const MEDIUM_RISK_INPUT = {
  projectName:        "MobileApp",
  domain:             "mobile",
  durationWeeks:      20,
  budgetUSD:          80000,
  teamSize:           5,
  teamExperience:     "mid",
  techStack:          "flutter",
  deadlineStrictness: "moderate",
};

// ── Validator Tests ────────────────────────────────────────────────────────

describe("Input Validator", () => {
  test("accepts valid high-risk input", () => {
    const { error, value } = validateInput(HIGH_RISK_INPUT);
    expect(error).toBeNull();
    expect(value.projectName).toBe("CriticalLaunch");
  });

  test("rejects missing projectName", () => {
    const { error } = validateInput({ ...HIGH_RISK_INPUT, projectName: "" });
    expect(error).toContain("projectName");
  });

  test("rejects invalid domain", () => {
    const { error } = validateInput({ ...HIGH_RISK_INPUT, domain: "gaming" });
    expect(error).toContain("domain");
  });

  test("rejects negative budget", () => {
    const { error } = validateInput({ ...HIGH_RISK_INPUT, budgetUSD: -100 });
    expect(error).toContain("budgetUSD");
  });

  test("rejects duration of 0", () => {
    const { error } = validateInput({ ...HIGH_RISK_INPUT, durationWeeks: 0 });
    expect(error).toContain("durationWeeks");
  });

  test("rejects teamSize > 500", () => {
    const { error } = validateInput({ ...HIGH_RISK_INPUT, teamSize: 501 });
    expect(error).toContain("teamSize");
  });

  test("rejects invalid deadlineStrictness", () => {
    const { error } = validateInput({ ...HIGH_RISK_INPUT, deadlineStrictness: "asap" });
    expect(error).toContain("deadlineStrictness");
  });
});

// ── Risk Engine Unit Tests ─────────────────────────────────────────────────

describe("Risk Engine — High Risk Scenario", () => {
  let report;
  beforeAll(() => { report = runRiskEngine(HIGH_RISK_INPUT); });

  test("returns a report object", () => {
    expect(report).toBeDefined();
    expect(report.projectName).toBe("CriticalLaunch");
  });

  test("overall severity is High", () => {
    expect(report.overallSeverity).toBe("High");
  });

  test("overall score is above 0.65", () => {
    expect(report.overallScore).toBeGreaterThan(0.65);
  });

  test("detects at least 4 risks", () => {
    expect(report.risks.length).toBeGreaterThanOrEqual(4);
  });

  test("detects at least one Schedule risk", () => {
    const scheduleRisks = report.risks.filter((r) => r.category === "Schedule");
    expect(scheduleRisks.length).toBeGreaterThan(0);
  });

  test("detects at least one Technical risk", () => {
    const techRisks = report.risks.filter((r) => r.category === "Technical");
    expect(techRisks.length).toBeGreaterThan(0);
  });

  test("each risk has required fields", () => {
    report.risks.forEach((risk) => {
      expect(risk).toHaveProperty("id");
      expect(risk).toHaveProperty("category");
      expect(risk).toHaveProperty("title");
      expect(risk).toHaveProperty("severity");
      expect(risk).toHaveProperty("probability");
      expect(risk).toHaveProperty("impact");
      expect(risk).toHaveProperty("confidence");
      expect(risk).toHaveProperty("explanation");
      expect(risk).toHaveProperty("mitigation");
      expect(Array.isArray(risk.mitigation)).toBe(true);
    });
  });

  test("probability and impact are in range 0–1", () => {
    report.risks.forEach((risk) => {
      expect(risk.probability).toBeGreaterThanOrEqual(0);
      expect(risk.probability).toBeLessThanOrEqual(1);
      expect(risk.impact).toBeGreaterThanOrEqual(0);
      expect(risk.impact).toBeLessThanOrEqual(1);
    });
  });

  test("confidence is in range 0–100", () => {
    report.risks.forEach((risk) => {
      expect(risk.confidence).toBeGreaterThanOrEqual(0);
      expect(risk.confidence).toBeLessThanOrEqual(100);
    });
  });
});

describe("Risk Engine — Low Risk Scenario", () => {
  let report;
  beforeAll(() => { report = runRiskEngine(LOW_RISK_INPUT); });

  test("overall severity is Low or Medium", () => {
    expect(["Low", "Medium"]).toContain(report.overallSeverity);
  });

  test("overall score is below 0.65", () => {
    expect(report.overallScore).toBeLessThan(0.65);
  });

  test("detects fewer risks than high-risk scenario", () => {
    const highReport = runRiskEngine(HIGH_RISK_INPUT);
    expect(report.risks.length).toBeLessThanOrEqual(highReport.risks.length);
  });
});

describe("Risk Engine — Medium Risk Scenario", () => {
  let report;
  beforeAll(() => { report = runRiskEngine(MEDIUM_RISK_INPUT); });

  test("returns a valid report", () => {
    expect(report).toBeDefined();
    expect(typeof report.overallScore).toBe("number");
  });

  test("summary is a non-empty string", () => {
    expect(typeof report.summary).toBe("string");
    expect(report.summary.length).toBeGreaterThan(10);
  });

  test("dimensions object has all four keys", () => {
    const { dimensions } = report;
    expect(dimensions).toHaveProperty("timelinePressure");
    expect(dimensions).toHaveProperty("budgetConstraint");
    expect(dimensions).toHaveProperty("experienceRisk");
    expect(dimensions).toHaveProperty("technicalComplexity");
  });
});

describe("Risk Engine — Edge Cases", () => {
  test("handles budget of 0 gracefully", () => {
    const report = runRiskEngine({ ...HIGH_RISK_INPUT, budgetUSD: 0 });
    expect(report.overallScore).toBeGreaterThan(0.5);
  });

  test("handles single team member", () => {
    const report = runRiskEngine({ ...LOW_RISK_INPUT, teamSize: 1 });
    const resourceRisk = report.risks.find((r) => r.category === "Resource");
    expect(resourceRisk).toBeDefined();
  });

  test("handles very large team (100 members)", () => {
    const report = runRiskEngine({ ...LOW_RISK_INPUT, teamSize: 100 });
    const commsRisk = report.risks.find((r) => r.category === "Communication");
    expect(commsRisk).toBeDefined();
  });

  test("handles maximum duration (260 weeks)", () => {
    const report = runRiskEngine({ ...HIGH_RISK_INPUT, durationWeeks: 260 });
    expect(report).toBeDefined();
    expect(report.overallScore).toBeGreaterThanOrEqual(0);
  });
});

// ── HTTP Integration Tests ─────────────────────────────────────────────────

describe("POST /api/analyze — HTTP Integration", () => {
  test("returns 200 with valid input", async () => {
    const res = await request(app).post("/api/analyze").send(HIGH_RISK_INPUT);
    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data).toBeDefined();
  });

  test("returns 400 with invalid input", async () => {
    const res = await request(app)
      .post("/api/analyze")
      .send({ projectName: "", domain: "invalid" });
    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.error).toBeDefined();
  });

  test("health endpoint returns ok", async () => {
    const res = await request(app).get("/health");
    expect(res.status).toBe(200);
    expect(res.body.status).toBe("ok");
  });

  test("response format contains all top-level fields", async () => {
    const res = await request(app).post("/api/analyze").send(LOW_RISK_INPUT);
    const { data } = res.body;
    expect(data).toHaveProperty("projectName");
    expect(data).toHaveProperty("overallScore");
    expect(data).toHaveProperty("overallSeverity");
    expect(data).toHaveProperty("overallConfidence");
    expect(data).toHaveProperty("risks");
    expect(data).toHaveProperty("dimensions");
    expect(data).toHaveProperty("summary");
    expect(data).toHaveProperty("categoryDistribution");
  });
});
