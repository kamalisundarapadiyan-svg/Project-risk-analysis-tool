/**
 * utils/scoring.js
 * Pure helper functions for normalising raw project data into
 * 0–1 pressure scores used by the risk engine heuristics.
 */

/**
 * Maps deadline strictness to a numeric pressure coefficient.
 *   flexible  → 0.2
 *   moderate  → 0.5
 *   strict    → 0.8
 *   critical  → 1.0
 */
const DEADLINE_WEIGHT = {
  flexible: 0.2,
  moderate: 0.5,
  strict:   0.8,
  critical: 1.0,
};

/**
 * Maps team experience to an experience coefficient.
 *   senior → 0.1  (low risk)
 *   mid    → 0.4
 *   mixed  → 0.6
 *   junior → 0.9  (high risk)
 */
const EXPERIENCE_WEIGHT = {
  senior: 0.1,
  mid:    0.4,
  mixed:  0.6,
  junior: 0.9,
};

/**
 * Maps tech stack to a complexity coefficient.
 * More niche/modern stacks carry higher inherent complexity.
 */
const TECH_COMPLEXITY = {
  react:        0.3,
  angular:      0.35,
  vue:          0.28,
  nodejs:       0.3,
  python:       0.25,
  java:         0.35,
  dotnet:       0.35,
  flutter:      0.4,
  kotlin:       0.45,
  swift:        0.45,
  rust:         0.7,
  go:           0.5,
  blockchain:   0.85,
  "ai-ml":      0.8,
  custom:       0.75,
  embedded:     0.7,
  cybersecurity:0.65,
};

/**
 * Calculates timeline pressure (0–1).
 * Short + strict = very high pressure.
 */
function timelinePressure(durationWeeks, deadlineStrictness) {
  // Normalise duration: <4 weeks → 1.0, >52 weeks → 0.0
  const durationScore = Math.max(0, Math.min(1, 1 - (durationWeeks - 4) / 48));
  const deadlineScore = DEADLINE_WEIGHT[deadlineStrictness] ?? 0.5;
  return (durationScore * 0.6) + (deadlineScore * 0.4);
}

/**
 * Calculates budget constraint score (0–1).
 * Low budget-per-member = high constraint.
 */
function budgetConstraint(budgetUSD, teamSize) {
  const perMember = budgetUSD / Math.max(teamSize, 1);
  // Thresholds (USD / person): <5k → critical, >100k → comfortable
  const normalised = Math.max(0, Math.min(1, 1 - (perMember - 5000) / 95000));
  return normalised;
}

/**
 * Returns the experience risk coefficient (0–1).
 */
function experienceRisk(teamExperience) {
  return EXPERIENCE_WEIGHT[teamExperience] ?? 0.5;
}

/**
 * Returns technical complexity score (0–1).
 */
function technicalComplexity(techStack, domain) {
  const stackScore = TECH_COMPLEXITY[techStack] ?? 0.5;
  // Some domains inherently amplify complexity
  const domainMultiplier =
    ["ai-ml", "cybersecurity", "blockchain", "embedded", "iot"].includes(domain)
      ? 1.25
      : 1.0;
  return Math.min(1, stackScore * domainMultiplier);
}

/**
 * Composite risk score using weighted formula:
 *   score = (timeline * 0.4) + (budget * 0.3) + (experience * 0.2) + (tech * 0.1)
 */
function compositeRiskScore(t, b, e, x) {
  return t * 0.4 + b * 0.3 + e * 0.2 + x * 0.1;
}

/**
 * Maps a 0–1 score to a severity label.
 */
function severityLabel(score) {
  if (score >= 0.65) return "High";
  if (score >= 0.35) return "Medium";
  return "Low";
}

/**
 * Derives a confidence score (0–100) based on how many
 * strong signals (extreme values) are present.
 */
function confidenceScore(t, b, e, x) {
  const extremes = [t, b, e, x].filter((v) => v >= 0.7 || v <= 0.2).length;
  const base = 60;
  return Math.min(98, base + extremes * 9 + Math.random() * 3); // slight jitter
}

module.exports = {
  timelinePressure,
  budgetConstraint,
  experienceRisk,
  technicalComplexity,
  compositeRiskScore,
  severityLabel,
  confidenceScore,
};
