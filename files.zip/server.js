/**
 * server.js — Entry point for the Project Risk Analysis API
 * Initializes Express app, middleware, and routes.
 */

const express = require("express");
const cors = require("cors");
const analyzeRoutes = require("./routes/analyze");

const app = express();
const PORT = process.env.PORT || 5000;

// ── Middleware ─────────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());

// Request logger (lightweight — no external dep)
app.use((req, _res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  next();
});

// ── Routes ─────────────────────────────────────────────────────────────────
app.use("/api", analyzeRoutes);

// Health check
app.get("/health", (_req, res) => res.json({ status: "ok", version: "1.0.0" }));

// 404 fallback
app.use((_req, res) => res.status(404).json({ error: "Route not found" }));

// ── Start ──────────────────────────────────────────────────────────────────
app.listen(PORT, () =>
  console.log(`✅  Risk Analysis API running on http://localhost:${PORT}`)
);

module.exports = app; // exported for Jest/supertest
