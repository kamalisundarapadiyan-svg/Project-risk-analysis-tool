/**
 * utils/validator.js
 * Validates and normalises the raw project input from the request body.
 * Returns { error, value } — error is null on success.
 */

const VALID_DOMAINS = [
  "software", "hardware", "data-science", "cybersecurity",
  "iot", "cloud", "mobile", "web", "ai-ml", "embedded",
];

const VALID_EXPERIENCE = ["junior", "mid", "senior", "mixed"];
const VALID_DEADLINE   = ["flexible", "moderate", "strict", "critical"];
const VALID_TECH_STACKS = [
  "react", "angular", "vue", "nodejs", "python", "java", "dotnet",
  "flutter", "kotlin", "swift", "rust", "go", "blockchain", "custom",
];

/**
 * Clamps a number between min and max.
 */
const clamp = (v, min, max) => Math.min(Math.max(Number(v), min), max);

/**
 * Validates project input.
 * @param {object} body - raw request body
 * @returns {{ error: string|null, value: object }}
 */
function validateInput(body) {
  const errors = [];

  // ── Required string fields ───────────────────────────────────────────────
  if (!body.projectName || typeof body.projectName !== "string" || !body.projectName.trim()) {
    errors.push("projectName is required");
  }

  // ── Domain ───────────────────────────────────────────────────────────────
  if (!VALID_DOMAINS.includes(body.domain)) {
    errors.push(`domain must be one of: ${VALID_DOMAINS.join(", ")}`);
  }

  // ── Duration (weeks, 1–260) ──────────────────────────────────────────────
  const duration = Number(body.durationWeeks);
  if (isNaN(duration) || duration < 1 || duration > 260) {
    errors.push("durationWeeks must be a number between 1 and 260");
  }

  // ── Budget (USD) ─────────────────────────────────────────────────────────
  const budget = Number(body.budgetUSD);
  if (isNaN(budget) || budget < 0) {
    errors.push("budgetUSD must be a non-negative number");
  }

  // ── Team size ─────────────────────────────────────────────────────────────
  const teamSize = Number(body.teamSize);
  if (isNaN(teamSize) || teamSize < 1 || teamSize > 500) {
    errors.push("teamSize must be between 1 and 500");
  }

  // ── Team experience ──────────────────────────────────────────────────────
  if (!VALID_EXPERIENCE.includes(body.teamExperience)) {
    errors.push(`teamExperience must be one of: ${VALID_EXPERIENCE.join(", ")}`);
  }

  // ── Tech stack ───────────────────────────────────────────────────────────
  if (!VALID_TECH_STACKS.includes(body.techStack)) {
    errors.push(`techStack must be one of: ${VALID_TECH_STACKS.join(", ")}`);
  }

  // ── Deadline strictness ──────────────────────────────────────────────────
  if (!VALID_DEADLINE.includes(body.deadlineStrictness)) {
    errors.push(`deadlineStrictness must be one of: ${VALID_DEADLINE.join(", ")}`);
  }

  if (errors.length > 0) {
    return { error: errors.join("; "), value: null };
  }

  // ── Normalised value object ───────────────────────────────────────────────
  const value = {
    projectName:       body.projectName.trim(),
    domain:            body.domain,
    durationWeeks:     clamp(duration, 1, 260),
    budgetUSD:         clamp(budget, 0, 1e9),
    teamSize:          clamp(teamSize, 1, 500),
    teamExperience:    body.teamExperience,
    techStack:         body.techStack,
    deadlineStrictness: body.deadlineStrictness,
  };

  return { error: null, value };
}

module.exports = { validateInput };
